package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Map;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

public class SimpleDynamoProvider extends ContentProvider {
	static final String TAG = "SimpleDht";
	static final String[] REMOTE_PORT = {"11108","11112","11116","11120","11124"};
	private static final String KEY_FIELD = "key";
	private static final String VALUE_FIELD = "value";
	Map<String, String> map = new HashMap<String, String>();
	ArrayList<String> Hash = new ArrayList<String>();
	ArrayList<String> LKey = new ArrayList<String>();
	ArrayList<String> fail = new ArrayList<String>();
	static final int SERVER_PORT = 10000;
	String myPort;

	public boolean fileExists(String filename) {
		return Arrays.asList(getContext().fileList()).contains(filename);
	}

	String findSucc(String port){
		String succ = null;
		try {
			int index = Hash.indexOf(genHash(port));
			if (index == (Hash.size() - 1)) {
				succ = Hash.get(0);
			} else succ = Hash.get(index + 1);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return succ;
	}

	String findPrev(String port){
		int index = Hash.indexOf(port);
		Log.d("IN findPrev index",String.valueOf(index));
		String prev = null;
		for(int i=0;i<Hash.size();i++) {
			if (Hash.get(i).equals(port)) {
				if (index == 0) {
					prev = Hash.get(4);
				} else {
					prev = Hash.get(i-1);
				}
			}
		}
		return prev;
	}

	boolean CheckStorage(String keyh, String port){
		Hash.add(keyh);
		Collections.sort(Hash);
		int index = Hash.indexOf(keyh);
		if(index==(Hash.size()-1)){
			if(Hash.get(0).equals(port)){
				Hash.remove(index);
				return true;
			}
		}
		else if(Hash.get(index+1).equals(port)){
			Hash.remove(index);
			return true;
		}
		Hash.remove(index);
		return false;
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		for(String f: REMOTE_PORT) {
			if(f.equals(myPort)) {
				String[] k = getContext().fileList();
				for (int j = 0; j < k.length; j++) {
					if (!k[j].equals("Update")) {
						getContext().deleteFile(k[j]);
					}
				}
			}
			else{
				Socket sf = null;
				try {
					sf = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
							Integer.parseInt(f));
				} catch (IOException e) {
					e.printStackTrace();
				}
				DataOutputStream op = null;
				try {
					op = new DataOutputStream(sf.getOutputStream());
				} catch (IOException e) {
					e.printStackTrace();
				}
				String m = "Delete,do";
				Log.d("delete send", m);
				try {
					op.writeUTF(m);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return 0;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		String fileName = (String) values.get(KEY_FIELD);
		String fileContent = (String) values.get(VALUE_FIELD);
		String Im = fileName+","+fileContent;
		new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,"Insert",Im);
		return null;
	}

	@Override
	public boolean onCreate() {
		TelephonyManager tel = (TelephonyManager) this.getContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		myPort = String.valueOf((Integer.parseInt(portStr) * 2));

		try {
			for(String r: REMOTE_PORT){
				Hash.add(genHash(String.valueOf(Integer.parseInt(r)/2)));
				Log.d("Ports",genHash(String.valueOf(Integer.parseInt(r)/2)));
			}
			Collections.sort(Hash);
			for(String i: Hash){
				Log.d("Hash list",i);
			}
			ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
			new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
			Log.d("My port",myPort);

			if(!(fileExists("Update"))){
				Log.d("First time","Set Update in file");
				FileOutputStream outputStream = getContext().openFileOutput("Update", Context.MODE_PRIVATE);
				outputStream.write("New".getBytes());
				outputStream.close();
			}
			else{
				new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, "Update", "do");
			}

		} catch (IOException e) {
			Log.e(TAG, "Can't create a ServerSocket");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return false;
	}

	private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

		@Override
		protected Void doInBackground(ServerSocket... sockets) {
			ServerSocket serverSocket = sockets[0];
			for (String r : REMOTE_PORT) {
				try {
					String mh = String.valueOf((Integer.parseInt(r) / 2));
					String kh = genHash(mh);
					map.put(kh, mh);
				} catch (NoSuchAlgorithmException e) {
					e.printStackTrace();
				}
			}
			try {
				while(true) {
					Socket clientSocket = serverSocket.accept();

					DataInputStream mes = new DataInputStream(clientSocket.getInputStream());
					String message = mes.readUTF();

					DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());

					Log.d("Receive m:", message);
					String[] M_arr = message.split(",");


					 if(M_arr[0].equals("Replicate")){
					 	try {
							Log.d("Receive rep", M_arr[1] + ":" + M_arr[2]);
							FileOutputStream outputStream = getContext().openFileOutput(M_arr[1], Context.MODE_PRIVATE);
							outputStream.write(M_arr[2].getBytes());
							outputStream.close();
							out.writeUTF("ACK");
						} catch (IOException e){
					 		e.printStackTrace();
						}
					}
					else if(M_arr[0].equals("Query")){
						try {
							String key = M_arr[1];
							FileInputStream in = getContext().openFileInput(key);
							InputStreamReader inputStreamReader = new InputStreamReader(in);
							BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
							StringBuilder sb = new StringBuilder();
							String line;
							while ((line = bufferedReader.readLine()) != null) {
								sb.append(line);
							}
							String m = key + "," + sb;
							Log.d("Q server", m);
							out.writeUTF(m);
						} catch (IOException e){
							e.printStackTrace();
						}
					}
					else if(M_arr[0].equals("Star")){
						 String[] keys = getContext().fileList();
						 StringBuilder b = new StringBuilder();
						 b.append(String.valueOf(keys.length));
						 for(int i=0;i<keys.length;i++){
							 if(!keys[i].equals("Update")) {
								 b.append("," + keys[i]);
								 FileInputStream in = getContext().openFileInput(keys[i]);
								 InputStreamReader inputStreamReader = new InputStreamReader(in);
								 BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
								 StringBuilder sb = new StringBuilder();
								 String line;
								 while ((line = bufferedReader.readLine()) != null) {
									 sb.append(line);
								 }
								 String val = sb.toString();
								 b.append(":" + val);
							 }
						 }
						 String m = b.toString();
						 out.writeUTF(m);
					 }
					else if(M_arr[0].equals("Global")){
						String[] keys = getContext().fileList();
						StringBuilder b = new StringBuilder();
						b.append(String.valueOf(keys.length));
						for(int i=0;i<keys.length;i++){
							if(!keys[i].equals("Update")) {
								b.append("," + keys[i]);
								FileInputStream in = getContext().openFileInput(keys[i]);
								InputStreamReader inputStreamReader = new InputStreamReader(in);
								BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
								StringBuilder sb = new StringBuilder();
								String line;
								while ((line = bufferedReader.readLine()) != null) {
									sb.append(line);
								}
								String val = sb.toString();
								b.append(":" + val);
							}
						}
						 StringBuilder g = new StringBuilder();
						 String k = null;
						 if(fail.size()==0){
							 k = "Empty";
						 }
						 else {
							 for (int i = 0; i < fail.size(); i++) {
								 String[] kv = fail.get(i).split(":");
								 g.append(kv[0] + ":" + kv[1] + ",");
							 }
							 g.append("end");
							 k = g.toString();
						 }
						b.append("."+k);
						String m = b.toString();
						out.writeUTF(m);
					}

					else if(M_arr[0].equals("Delete")){
						 String[] ke = getContext().fileList();
						 Log.d("size after del", String.valueOf(ke.length));
						 for (int i = 0; i < ke.length; i++) {
						 	if(!ke[i].equals("Update")) {
								getContext().deleteFile(ke[i]);
							}
						 }

					}
					else if(M_arr[0].equals("RepDel")){
						String toD = M_arr[1];
						Log.d("Key to repDelete",toD);
						getContext().deleteFile(toD);


					}
				}


			} catch (IOException e) {
				e.printStackTrace();
			}


			return null;
		}

		protected void onProgressUpdate(String...strings) {
			/*
			 * The following code displays what is received in doInBackground().
			 */
			super.onProgressUpdate(strings);
			String strReceived = strings[0].trim();


			return;
		}
	}

	private class ClientTask extends AsyncTask<String, Void, Void> {

		@Override
		protected Void doInBackground(String... msgs) {
			try {

				if(msgs[0].equals("Insert")) {
					String[] q = msgs[1].split(",");
					String k = q[0];
					String v = q[1];
						String kH = genHash(k);
						String sPort = null;
						int index = 0;
						Hash.add(kH);
						Collections.sort(Hash);
						Log.d("In insert",String.valueOf(Hash.size()));
						index = Hash.indexOf(kH);
						if ((index + 1) >= Hash.size()) {
							sPort = map.get(Hash.get(0));
						} else {
							sPort = map.get(Hash.get(index + 1));
						}
						Hash.remove(index);
						ArrayList<Integer> ports = new ArrayList<Integer>();
						Log.d("Server In:", k + ":" + v + ":" + kH);
						int inde = 0;
						inde = Hash.indexOf(genHash(String.valueOf(Integer.parseInt(sPort))));
						Log.d("server index",String.valueOf(inde)+":"+sPort);
						ports.add(inde);
						int in = 0;
						int c =0;
						for(int j=0;j<2;j++){
							in = inde + 1;
							if(in > (Hash.size()-1)){
								inde = 0;
								ports.add(0+c);
								c++;
							}
							else {
								ports.add(in);
								inde++;
							}
						}
						for(int j=0;j<3;j++){
							try {
								Socket sr = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
										Integer.parseInt(map.get(Hash.get(ports.get(j)))) * 2);
								DataOutputStream rep = new DataOutputStream(sr.getOutputStream());
								String rm = "Replicate," + k + "," + v;
								Log.d("send rep", rm + ":" + map.get(Hash.get(ports.get(j))));
								rep.writeUTF(rm);
								DataInputStream po = new DataInputStream(sr.getInputStream());
								String reply = po.readUTF();
							}
							catch (IOException e){
								fail.add(k+":"+v);
								continue;

							}

						}

				}
				else if(msgs[0].equals("Update")){
					String[] keys = getContext().fileList();
					for (int i = 0; i < keys.length; i++) {
						if(!keys[i].equals("Update")){
							getContext().deleteFile(keys[i]);
						}
					}
					Log.d("In client update","reached");
					String phash = genHash(String.valueOf(Integer.parseInt(myPort)/2));
					String prevh = findPrev(phash);
					String secph = findPrev(prevh);
					Log.d("In update",prevh+":"+secph);
					ArrayList<String> KL = new ArrayList<String>();
					ArrayList<String> VaL = new ArrayList<String>();
					for (String rm : REMOTE_PORT) {
						if (rm.equals(myPort)) {
							continue;
						} else {
							String p = null;
							try {
								Socket ls = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
										Integer.parseInt(rm));
								DataOutputStream gl = new DataOutputStream(ls.getOutputStream());
								String m = "Global,Do";
								gl.writeUTF(m);
								DataInputStream got = new DataInputStream(ls.getInputStream());
								p = got.readUTF();
								if (p != null) {
								String[] l = p.split("\\.");
								String[] jn = l[0].split(",");
								int loclen = Integer.parseInt(jn[0]);
								for (int i = 1; i < loclen; i++) {
									String[] kv = jn[i].split(":");
									KL.add(kv[0]);
									VaL.add(kv[1]);
								}
								String r = l[1];
								if (!r.equals("Empty")) {
									String[] f = r.split(",");
									for (int i = 0; i < (f.length - 1); i++) {
										String[] kv = f[i].split(":");
										KL.add(kv[0]);
										VaL.add(kv[1]);
									}
								}
							}
						}
						catch (SocketException e) {
								e.printStackTrace();
						}
						catch (IOException e) {
							e.printStackTrace();
							}
						}
					}
					Log.d("Total size:",String.valueOf(KL.size()));
					for(int i=0;i<KL.size();i++){
						String kh = genHash(KL.get(i));
						if(CheckStorage(kh,phash) || CheckStorage(kh,prevh) || CheckStorage(kh,secph)){
							Log.d("Yes belongs","inserting...");
							FileOutputStream outputStream = getContext().openFileOutput(KL.get(i), Context.MODE_PRIVATE);
							outputStream.write(VaL.get(i).getBytes());
							outputStream.close();
						}
					}
				}

			} catch (UnknownHostException e) {
				Log.e(TAG, "ClientTask UnknownHostException");
			} catch (IOException e) {
				e.printStackTrace();
			}
			 catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}

			return null;
		}


	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		String[] columnNames = {KEY_FIELD, VALUE_FIELD};
		Log.d("Query",selection);
		MatrixCursor matrixCursor = new MatrixCursor(columnNames);
		try {
			if(selection.equals("*")) {
				if(Hash.size()==1){
					for (int i = 0; i < LKey.size(); i++) {
						FileInputStream in = getContext().openFileInput(LKey.get(i));
						InputStreamReader inputStreamReader = new InputStreamReader(in);
						BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
						StringBuilder sb = new StringBuilder();
						String line;
						while ((line = bufferedReader.readLine()) != null) {
							sb.append(line);
						}
						Log.d("Found:", selection + ":" + sb);
						MatrixCursor.RowBuilder RBuilder = matrixCursor.newRow();
						RBuilder.add(columnNames[0], LKey.get(i));
						RBuilder.add(columnNames[1], sb);
						in.close();
					}
				}
				else {
					ArrayList<String> GL = new ArrayList<String>();
					ArrayList<String> VL = new ArrayList<String>();
					ArrayList<String> ports = new ArrayList<String>();
					for(int p=0;p<Hash.size();p++){
						String l = map.get(Hash.get(p));
						String fl = String.valueOf(Integer.parseInt(l)*2);
						ports.add(fl);
					}
					Log.d("Ports Alive",String.valueOf(ports.size()));
					for (String rm : ports) {
						try {
							if (rm.equals(myPort)) {
								String[] keys = getContext().fileList();
								for (int i = 0; i < keys.length; i++) {
									if (!(keys[i].equals("Update"))) {
										Log.d("In local star", "Entered");
										FileInputStream in = getContext().openFileInput(keys[i]);
										InputStreamReader inputStreamReader = new InputStreamReader(in);
										BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
										StringBuilder sb = new StringBuilder();
										String line;
										while ((line = bufferedReader.readLine()) != null) {
											sb.append(line);
										}
										String val = sb.toString();
										GL.add(keys[i]);
										VL.add(val);
									}
								}
							} else {
								Socket ls = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
										Integer.parseInt(rm));
								DataOutputStream gl = new DataOutputStream(ls.getOutputStream());
								String m = "Star,Do";
								gl.writeUTF(m);
								DataInputStream got = new DataInputStream(ls.getInputStream());
								String p = got.readUTF();
								String[] l = p.split(",");
								for (int i = 1; i < Integer.parseInt(l[0]); i++) {
									String[] kv = l[i].split(":");
									GL.add(kv[0]);
									VL.add(kv[1]);
								}
							}
						} catch (IOException e){
							continue;
						}
					}

					Log.d("Global Size", String.valueOf(GL.size()));
					for (int i = 0; i < GL.size(); i++) {
						MatrixCursor.RowBuilder RBuilder = matrixCursor.newRow();
						RBuilder.add(columnNames[0], GL.get(i));
						RBuilder.add(columnNames[1], VL.get(i));
					}
				}
			}
			else if(selection.equals("@")){
				String[] keys = getContext().fileList();
				for (int i = 0; i < keys.length; i++) {
					if(!(keys[i].equals("Update"))) {
						FileInputStream in = getContext().openFileInput(keys[i]);
						InputStreamReader inputStreamReader = new InputStreamReader(in);
						BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
						StringBuilder sb = new StringBuilder();
						String line;
						while ((line = bufferedReader.readLine()) != null) {
							sb.append(line);
						}
						Log.d("Found:", selection + ":" + sb);
						MatrixCursor.RowBuilder RBuilder = matrixCursor.newRow();
						RBuilder.add(columnNames[0], keys[i]);
						RBuilder.add(columnNames[1],sb);
						in.close();
					}
				}
			}
			else if(Hash.size()==1){
				FileInputStream in = getContext().openFileInput(selection);
				InputStreamReader inputStreamReader = new InputStreamReader(in);
				BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
				StringBuilder sb = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					sb.append(line);
				}
				Log.d("Found:", selection + ":" + sb);
				MatrixCursor.RowBuilder RBuilder = matrixCursor.newRow();
				RBuilder.add(columnNames[0], selection);
				RBuilder.add(columnNames[1], sb);
				in.close();
			}
			else {
				int index = -1;
				String sPort = null;
				String kH = genHash(selection);
				Hash.add(kH);
				Collections.sort(Hash);
				index = Hash.indexOf(kH);
				if ((index + 1) >= Hash.size()) {
					sPort = map.get(Hash.get(0));
				} else {
					sPort = map.get(Hash.get(index + 1));
				}
				Hash.remove(index);
				String re = null;
 				for(int i = 0;i<3;i++) {
					try {
						Socket sf = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
								Integer.parseInt(sPort) * 2);
						DataOutputStream op = new DataOutputStream(sf.getOutputStream());
						String m = "Query," + selection;
						Log.d("Querying", m + ":" + sPort);
						op.writeUTF(m);
						DataInputStream in = new DataInputStream(sf.getInputStream());
						re = in.readUTF();
					} catch (IOException e) {
						String succ = map.get(findSucc(sPort));
						Log.d("cur:succ", sPort + ":" + succ);
						Socket sf = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
								Integer.parseInt(succ) * 2);
						DataOutputStream op = new DataOutputStream(sf.getOutputStream());
						String m = "Query," + selection;
						Log.d("Querying", m + ":" + sPort);
						op.writeUTF(m);
						DataInputStream in = new DataInputStream(sf.getInputStream());
						re = in.readUTF();
					}
				}
				String[] info = re.split(",");
				Log.d("Return q", re);
				MatrixCursor.RowBuilder RBuilder = matrixCursor.newRow();
				RBuilder.add(columnNames[0], info[0]);
				RBuilder.add(columnNames[1], info[1]);
			}
		} catch (IOException e) {
			e.printStackTrace();

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return matrixCursor;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }
}
